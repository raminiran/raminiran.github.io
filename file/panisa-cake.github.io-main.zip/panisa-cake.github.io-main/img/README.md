##### [panisa-cake.svg](https://raw.githubusercontent.com/panisa-cake/panisa-cake.github.io/18f10dbc6e14535c7bbf6080c86109434cc6720d/img/ico/panisa-cake.svg)
```
https://raw.githubusercontent.com/panisa-cake/panisa-cake.github.io/18f10dbc6e14535c7bbf6080c86109434cc6720d/img/ico/panisa-cake.svg

```
##### [log-d-500px.png](https://raw.githubusercontent.com/panisa-cake/panisa-cake.github.io/main/img/log-d-500px.png)
```
https://raw.githubusercontent.com/panisa-cake/panisa-cake.github.io/main/img/log-d-500px.png
```
