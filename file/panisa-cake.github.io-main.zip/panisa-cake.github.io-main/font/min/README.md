<div align="center" >

```
Vazir-Bold-FD.woff 
```

``` 
Vazir-FD.woff 
```

``` 
Vazir-Medium-FD.woff
```
  </div>
